import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { invokeEdgeFunction, AddVaultItemSchema, safeValidateInput } from "@/lib/edgeFunction";
import { logger } from "@/lib/logger";
import {
  AlertTriangle,
  CheckCircle2,
  Lightbulb,
  ArrowRight,
  TrendingUp,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { GapSolutionsCard } from "./GapSolutionsCard";
import { VisualResumePreview } from "./VisualResumePreview";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";

interface GapAnalysisViewProps {
  unmatchedRequirements: string[];
  coverageScore: number;
  totalRequirements: number;
  onContinue: () => void;
  vaultMatches?: any[];
  jobAnalysis?: any;
}

export const GapAnalysisView = ({
  unmatchedRequirements,
  coverageScore,
  totalRequirements,
  onContinue,
  vaultMatches = [],
  jobAnalysis
}: GapAnalysisViewProps) => {
  const { toast } = useToast();
  const matchedCount = totalRequirements - unmatchedRequirements.length;
  const gapCount = unmatchedRequirements.length;
  
  // Track which gaps are expanded and addressed
  const [expandedGaps, setExpandedGaps] = useState<Record<number, boolean>>({});
  const [addressedGaps, setAddressedGaps] = useState<Record<number, boolean>>({});

  const toggleGap = (index: number) => {
    setExpandedGaps(prev => ({ ...prev, [index]: !prev[index] }));
  };

  const handleAddToVault = async (index: number, solution: any) => {
    setAddressedGaps(prev => ({ ...prev, [index]: true }));
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get user's vault ID
      const { data: vault } = await supabase
        .from('career_vault')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (!vault) return;

      // Determine category based on solution type
      const category = solution.isEducation ? 'education' : 
                      solution.type === 'skill' ? 'transferable_skills' : 
                      'power_phrases';

      // Determine quality tier: vault-based = silver, AI = bronze
      const quality_tier = solution.approach === 'vault_based' ? 'silver' : 'bronze';

      // Save to appropriate vault table
      const payload = {
        vaultId: vault.id,
        category,
        itemData: {
          [category === 'power_phrases' ? 'power_phrase' : 
            category === 'transferable_skills' ? 'stated_skill' : 
            'content']: solution.content,
          quality_tier,
          source: 'gap_analysis',
          satisfies_requirement: unmatchedRequirements[index],
          confidence_score: solution.approach === 'vault_based' ? 85 : 70
        }
      };

      const validation = safeValidateInput(AddVaultItemSchema, payload);
      if (!validation.success) return;

      const { error } = await invokeEdgeFunction(
        'add-vault-item',
        payload
      );

      if (error) {
        logger.error('Failed to add vault item', error);
        return;
      }

      toast({
        title: "✅ Added to Career Vault",
        description: `This ${category.replace('_', ' ')} will be available for all future resumes`,
      });
    } catch (error: any) {
      logger.error('Error adding to vault', error);
    }
  };

  const getCoverageColor = () => {
    if (coverageScore >= 80) return "text-success";
    if (coverageScore >= 60) return "text-warning";
    return "text-destructive";
  };

  const getCoverageIcon = () => {
    if (coverageScore >= 80) return <CheckCircle2 className="h-6 w-6 text-success" />;
    return <AlertTriangle className="h-6 w-6 text-warning" />;
  };

  const addressedCount = Object.values(addressedGaps).filter(Boolean).length;

  // Prepare preview sections (placeholder for now)
  const previewSections = [
    { id: '1', type: 'summary', title: 'Executive Summary', content: [], order: 1, status: 'needs_attention' as const },
    { id: '2', type: 'experience', title: 'Professional Experience', content: [], order: 2, status: 'needs_attention' as const },
    { id: '3', type: 'skills', title: 'Core Competencies', content: [], order: 3, status: 'needs_attention' as const },
    { id: '4', type: 'education', title: 'Education', content: [], order: 4, status: 'needs_attention' as const },
  ];

  return (
    <div className="min-h-screen bg-background">
      <ResizablePanelGroup direction="horizontal" className="min-h-screen">
        {/* Left Panel: Gap Analysis */}
        <ResizablePanel defaultSize={50} minSize={40}>
          <div className="h-full overflow-auto p-6 space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-3">Gap Analysis Complete</h1>
          <p className="text-lg text-muted-foreground">
            Review how your Career Vault matches this job's requirements
          </p>
        </div>

        {/* Coverage Summary */}
        <Card className="p-6 bg-card border">
          <div className="flex items-start gap-4">
            {getCoverageIcon()}
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xl font-semibold">Coverage Score</h3>
                <div className={`text-3xl font-bold ${getCoverageColor()}`}>
                  {coverageScore}%
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Your Career Vault addresses {matchedCount} of {totalRequirements} requirements
              </p>

              <div className="w-full bg-muted rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all ${
                    coverageScore >= 80 ? 'bg-success' :
                    coverageScore >= 60 ? 'bg-warning' :
                    'bg-destructive'
                  }`}
                  style={{ width: `${coverageScore}%` }}
                />
              </div>

              {coverageScore >= 80 && (
                <div className="mt-4 flex items-start gap-2 text-success">
                  <TrendingUp className="h-4 w-4 mt-0.5" />
                  <p className="text-sm">
                    Excellent match! Your vault strongly supports this application.
                  </p>
                </div>
              )}
            </div>
          </div>
        </Card>

        {/* Gaps Section */}
        {gapCount > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold">
                Requirements Not Fully Matched ({gapCount})
              </h2>
              <div className="flex items-center gap-3">
                {addressedCount > 0 && (
                  <Badge variant="outline" className="bg-success/10 text-success border-success/30">
                    {addressedCount} Addressed
                  </Badge>
                )}
                {gapCount > addressedCount && (
                  <Badge variant="outline" className="bg-warning/10 text-warning border-warning/30">
                    {gapCount - addressedCount} Remaining
                  </Badge>
                )}
              </div>
            </div>

            <Alert className="border-primary/20 bg-primary/5">
              <Lightbulb className="h-4 w-4" />
              <AlertTitle>Click any requirement to see AI-generated solutions</AlertTitle>
              <AlertDescription>
                Each gap has three strategic approaches: industry standard, vault-based adaptation, 
                and alternative positioning. Choose the best solution and add it to your Career Vault.
              </AlertDescription>
            </Alert>

            {/* Gap Cards Grid */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {unmatchedRequirements.map((requirement, index) => {
                const isExpanded = expandedGaps[index];
                const isAddressed = addressedGaps[index];

                return (
                  <Collapsible
                    key={index}
                    open={isExpanded}
                    onOpenChange={() => toggleGap(index)}
                    className={`border rounded-lg transition-all ${
                      isExpanded ? 'col-span-full' : ''
                    }`}
                  >
                    <CollapsibleTrigger asChild>
                      <Card className={`p-4 cursor-pointer hover:shadow-md transition-all ${
                        isAddressed ? 'border-success/50 bg-success/5' : 'border-border'
                      }`}>
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              {isAddressed ? (
                                <CheckCircle2 className="h-4 w-4 text-success flex-shrink-0" />
                              ) : (
                                <AlertTriangle className="h-4 w-4 text-warning flex-shrink-0" />
                              )}
                              <Badge variant="outline" className="text-xs">
                                {isAddressed ? 'Addressed' : 'Needs Attention'}
                              </Badge>
                            </div>
                            <p className="text-sm font-medium line-clamp-3">
                              {requirement}
                            </p>
                          </div>
                          {isExpanded ? (
                            <ChevronUp className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
                          ) : (
                            <ChevronDown className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
                          )}
                        </div>
                        {!isExpanded && (
                          <Button
                            size="sm"
                            variant={isAddressed ? "outline" : "default"}
                            className="w-full mt-3"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleGap(index);
                            }}
                          >
                            {isAddressed ? 'Review Solution' : 'Address This'}
                          </Button>
                        )}
                      </Card>
                    </CollapsibleTrigger>
                    
                    <CollapsibleContent className="mt-4">
                      <GapSolutionsCard
                        requirement={requirement}
                        vaultMatches={vaultMatches}
                        jobContext={{
                          title: jobAnalysis?.roleProfile?.title || 'this role',
                          industry: jobAnalysis?.roleProfile?.industry || 'your industry',
                          seniority: jobAnalysis?.roleProfile?.seniority || 'mid-level'
                        }}
                        onAddToVault={(solution) => handleAddToVault(index, solution)}
                      />
                    </CollapsibleContent>
                  </Collapsible>
                );
              })}
            </div>
          </div>
        )}

        {/* No Gaps - Celebration */}
        {gapCount === 0 && (
          <Card className="p-6 bg-success/5 border-success/30">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-6 w-6 text-success" />
              <div>
                <h3 className="font-semibold text-success">Perfect Match!</h3>
                <p className="text-sm text-muted-foreground">
                  Your Career Vault addresses all job requirements. Ready to generate an exceptional resume.
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-6 border-t">
          <div className="text-sm text-muted-foreground">
            {addressedCount > 0 && gapCount > addressedCount && (
              <span>You've addressed {addressedCount} of {gapCount} gaps. You can continue or address more.</span>
            )}
            {addressedCount === gapCount && gapCount > 0 && (
              <span className="text-success font-medium">All gaps addressed! Ready to generate.</span>
            )}
          </div>
          <Button
            onClick={onContinue}
            size="lg"
            className="gap-2"
          >
            Continue to Resume Generation
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>

        {/* What Happens Next */}
        <Card className="p-4 bg-primary/5 border-primary/20">
          <div className="flex items-start gap-3">
            <Lightbulb className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-sm mb-2">What happens next</h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li className="flex items-start gap-2">
                  <span className="text-primary">1.</span>
                  <span>AI will generate your resume using <strong>all {matchedCount} matched vault items</strong></span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">2.</span>
                  <span>Solutions you've added will be integrated into the appropriate sections</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">3.</span>
                  <span>Each section shows which vault items were used and why</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">4.</span>
                  <span>You can review, edit, and approve each section before finalizing</span>
                </li>
              </ul>
            </div>
          </div>
        </Card>
          </div>
        </ResizablePanel>

        {/* Resizable Handle */}
        <ResizableHandle withHandle />

        {/* Right Panel: Live Resume Preview */}
        <ResizablePanel defaultSize={50} minSize={30}>
          <div className="h-full p-6">
            <VisualResumePreview
              sections={previewSections}
              addressedGaps={Object.keys(addressedGaps).filter(k => addressedGaps[Number(k)])}
              vaultMatches={vaultMatches}
              atsKeywords={jobAnalysis?.atsKeywords || { critical: [], important: [], nice_to_have: [] }}
            />
          </div>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
};
